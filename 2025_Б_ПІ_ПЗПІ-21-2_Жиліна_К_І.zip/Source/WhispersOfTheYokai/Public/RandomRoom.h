// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RandomRoom.generated.h"

USTRUCT()
struct FPlacedRectangle
{
    GENERATED_BODY()

    FVector Location; // Location of the rectangle's top-left corner
    FVector2D Size;   // Size of the rectangle (width, height)

    FPlacedRectangle() {}

    FPlacedRectangle(FVector InLocation, FVector2D InSize)
        : Location(InLocation), Size(InSize) {}

    // Returns the bounds of this rectangle as Min and Max vectors
    FBox2D GetBounds() const
    {
        return FBox2D(FVector2D(Location.X, Location.Y), FVector2D(Location.X + Size.X, Location.Y + Size.Y));
    }
};

UCLASS()
class WHISPERSOFTHEYOKAI_API ARandomRoom : public AActor
{
    GENERATED_BODY()

public:
    ARandomRoom();

protected:
    virtual void BeginPlay() override;

public:
    virtual void Tick(float DeltaTime) override;

    // Минимальный и максимальный размер для каждого прямоугольника
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Room Settings")
    FVector2D MinRoomSize;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Room Settings")
    FVector2D MaxRoomSize;

    // Максимальное количество прямоугольников в комнате
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Room Settings")
    int32 MaxRectangles;

    // Минимальное количество прямоугольников
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Room Settings")
    int32 MinRectangles;

    // Устанавливаем Static Mesh для использования
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Room Settings")
    UStaticMesh* RoomStaticMesh;

private:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Room Mesh", meta = (AllowPrivateAccess = "true"))
    class UStaticMeshComponent* RoomMesh;

    // Размер статического меша
    FVector2D MeshSize;

    // Хранит размещенные позиции мешей, чтобы избежать перекрытий
    TSet<FVector> PlacedMeshPositions;

    // Функция для генерации комнаты с несколькими прямоугольниками
    void GenerateRoomWithRectangles();
    void SpawnRectangle(FVector Location, FVector2D Size);
    bool IsPositionOccupied(const FVector& Position) const;
};
