#include "MyPlayerController.h"
#include "GameFramework/Pawn.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Components/InputComponent.h"

AMyPlayerController::AMyPlayerController()
{
}

void AMyPlayerController::BeginPlay()
{
    Super::BeginPlay();

    APawn* ControlledPawn = GetPawn();

    if (APlayerController* PlayerController = Cast<APlayerController>(this))
    {
        UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(PlayerController->InputComponent);

        if (EnhancedInputComponent)
        {
            EnhancedInputComponent->BindAction(IA_MoveForwardBackward, ETriggerEvent::Triggered, this, &AMyPlayerController::MoveForwardBackward);
            EnhancedInputComponent->BindAction(IA_MoveLeftRight, ETriggerEvent::Triggered, this, &AMyPlayerController::MoveLeftRight);
        }
    }
}

void AMyPlayerController::MoveForwardBackward(const FInputActionValue& Value)
{
    const float MoveValue = Value.Get<float>();

    if (MoveValue == 0.0f)
    {
        return;
    }

    APawn* ControlledPawn = GetPawn();
    if (ControlledPawn)
    {
        const FRotator ControllerRotation = GetControlRotation();
        const FRotator YawRotation(0.0f, ControllerRotation.Yaw, 0.0f);
        const FVector ForwardDirection = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);

        const FVector MoveDirection = ForwardDirection * MoveValue * MoveSpeed;
        ControlledPawn->AddActorWorldOffset(MoveDirection, true);
    }
}

void AMyPlayerController::MoveLeftRight(const FInputActionValue& Value)
{
    const float MoveValue = Value.Get<float>();

    if (MoveValue == 0.0f)
    {
        return;
    }

    APawn* ControlledPawn = GetPawn();
    if (ControlledPawn)
    {
        const FRotator ControllerRotation = GetControlRotation();
        const FRotator YawRotation(0.0f, ControllerRotation.Yaw, 0.0f);
        const FVector RightDirection = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);

        const FVector MoveDirection = RightDirection * MoveValue * MoveSpeed;
        ControlledPawn->AddActorWorldOffset(MoveDirection, true);
    }
}