#include "RandomRoom.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Engine/World.h"

// Конструктор
ARandomRoom::ARandomRoom()
{
    PrimaryActorTick.bCanEverTick = true;

    // Создаем Static Mesh Component для основного прямоугольника
    RoomMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RoomMesh"));
    RootComponent = RoomMesh;

    // Устанавливаем значения по умолчанию
    MinRoomSize = FVector2D(300.f, 300.f); // Минимум 3x3 метра
    MaxRoomSize = FVector2D(1000.f, 1000.f); // Максимум 10x10 метров
    MinRectangles = 2;  // Минимум 2 прямоугольника
    MaxRectangles = 5;  // Максимум 5 прямоугольников

    // Устанавливаем размер статического меша (45x45 см или 0.45x0.45 метра)
    MeshSize = FVector2D(45.f, 45.f);
}

void ARandomRoom::BeginPlay()
{
    Super::BeginPlay();

    // Set the static mesh if RoomStaticMesh is assigned
    if (RoomStaticMesh)
    {
        RoomMesh->SetStaticMesh(RoomStaticMesh);
    }

    // Генерируем комнату с несколькими прямоугольниками
    GenerateRoomWithRectangles();
}

void ARandomRoom::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void ARandomRoom::GenerateRoomWithRectangles()
{
    // Очищаем набор размещенных позиций перед генерацией новой комнаты
    PlacedMeshPositions.Empty();

    // Генерируем случайное количество прямоугольников
    int32 NumberOfRectangles = FMath::RandRange(MinRectangles, MaxRectangles);

    // Начальная позиция для первого прямоугольника
    FVector CurrentPosition = GetActorLocation();

    for (int32 i = 0; i < NumberOfRectangles; ++i)
    {
        // Генерируем случайный размер для каждого прямоугольника, кратный размеру меша
        float RandomWidth = FMath::RandRange(MinRoomSize.X, MaxRoomSize.X);
        float RandomHeight = FMath::RandRange(MinRoomSize.Y, MaxRoomSize.Y);

        // Приводим размеры к кратным размеру меша
        RandomWidth = FMath::RoundToInt(RandomWidth / MeshSize.X) * MeshSize.X;
        RandomHeight = FMath::RoundToInt(RandomHeight / MeshSize.Y) * MeshSize.Y;

        // Определяем смещение для следующего прямоугольника
        float OffsetX = FMath::RandRange(-RandomWidth, RandomWidth);
        float OffsetY = FMath::RandRange(-RandomHeight, RandomHeight);

        // Генерируем новую позицию с учётом смещения
        FVector NewPosition = CurrentPosition + FVector(OffsetX, OffsetY, 0.f);

        // Спавним прямоугольник в новой позиции
        SpawnRectangle(NewPosition, FVector2D(RandomWidth, RandomHeight));

        // Смещаем текущее положение для следующего прямоугольника
        CurrentPosition = NewPosition;
    }
}

void ARandomRoom::SpawnRectangle(FVector Location, FVector2D Size)
{
    // Делим прямоугольник на сетку и размещаем статический меш
    int32 NumColumns = Size.X / MeshSize.X;
    int32 NumRows = Size.Y / MeshSize.Y;

    for (int32 Row = 0; Row < NumRows; ++Row)
    {
        for (int32 Col = 0; Col < NumColumns; ++Col)
        {
            // Определяем позицию для каждого меша
            FVector MeshPosition = Location + FVector(Col * MeshSize.X, Row * MeshSize.Y, 0.f);

            // Проверяем, не занято ли это место
            if (!IsPositionOccupied(MeshPosition))
            {
                // Создаем и добавляем компонент статического меша
                UStaticMeshComponent* NewMesh = NewObject<UStaticMeshComponent>(this);
                NewMesh->SetStaticMesh(RoomMesh->GetStaticMesh());
                NewMesh->SetWorldLocation(MeshPosition);
                NewMesh->SetWorldScale3D(FVector(0.45f, 0.45f, 1.0f)); // Используем масштаб для соответствия 45x45 см
                NewMesh->RegisterComponent();
                NewMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepWorldTransform);

                // Добавляем эту позицию в набор занятых позиций
                PlacedMeshPositions.Add(MeshPosition);
            }
        }
    }

    // Лог для проверки
    UE_LOG(LogTemp, Warning, TEXT("Rectangle spawned at: %s with size: %f x %f"), *Location.ToString(), Size.X, Size.Y);
}

bool ARandomRoom::IsPositionOccupied(const FVector& Position) const
{
    return PlacedMeshPositions.Contains(Position);
}

